package com.morphic.iconpack

import android.app.Activity
import android.os.Bundle
import android.widget.TextView
import android.widget.LinearLayout
import android.graphics.Color
import android.view.Gravity

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(8, 8, 10))
        }
        val title = TextView(this).apply {
            text = "MORPHIC 3D ICON PACK"
            textSize = 25f
            setTextColor(Color.rgb(255, 204, 82))
            gravity = Gravity.CENTER
        }
        val body = TextView(this).apply {
            text = "\n300 individual icon artworks\nBlack glossy tiles • raised gold symbols\n\nThis is a starter icon-pack project.\nLauncher support depends on the launcher reading\nAndroid appfilter.xml icon-pack metadata.\n\nChoose Morphic 3D in your launcher's icon settings."
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        layout.addView(title)
        layout.addView(body)
        setContentView(layout)
    }
}
