MORPHIC 3D ICON PACK - STARTER ANDROID PROJECT

Included:
- 300 individually generated 192x192 PNG icon artworks
- Semantic aliases for common app categories
- appfilter.xml starter mappings for popular Android apps
- Basic Android Studio project (Kotlin + Gradle)

IMPORTANT:
This is a source project, not a compiled APK. It does not include a full CandyBar dashboard.
Launcher icon-pack support varies. Microsoft Launcher and Slate Launcher may not expose
the standard appfilter interface, so do not assume the pack will apply there until tested.

BUILD:
1. Install Android Studio on a computer.
2. Open this folder as an existing project.
3. Allow Gradle sync to finish.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Locate app-debug.apk under app/build/outputs/apk/debug/.

To improve compatibility and add one-tap apply support, a full launcher-specific dashboard
and exact component mappings are still required. The included appfilter entries use common
package IDs and generic activity names; some launchers require exact activity names.
